#include <iostream>

#include "Bibliotecas/AdministrarMetricas.h"

using namespace std;

int main() {
    AdministrarMetricas lista;

    lista.cargarArchivo("ArchivosDeDatos/metricas.csv");

    return 0;
}
